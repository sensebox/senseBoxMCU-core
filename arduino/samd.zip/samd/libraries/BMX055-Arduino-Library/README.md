# BMX 055 Arduino Library
Arduino Library which holds only the BMX library, slightly fixed for the use with the BMX055 on senseBox MCU


