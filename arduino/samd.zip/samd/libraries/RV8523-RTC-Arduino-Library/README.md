# RV8523-RTC-Arduino-Library
Arduino Library for the RV8523 RTC. Insert the small battery, connect the senseBox RTC Module with an JST-JST Cable to an I2C-Port and set the clock with the example code.

## Copyright and Licence

This Library was developed by [Watterott Electronic](https://shop.watterott.com/) and extracted from their [Arduino Library](https://github.com/watterott/Arduino-Libs) Repository 
