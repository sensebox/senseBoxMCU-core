# WiFi101 Web Server

Currently a very small C++ HTTP server library for the senseBox MCU.

It should not be used in public or production systems.  
It was meant for the usage in combination with Blockly for the senseBox MCU.  
In that environment it can be used as an education tool to teach students, how an HTTP server works
and how an HTML page is build.
